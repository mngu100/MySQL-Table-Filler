import tkinter as tk
import tkinter.font as tkFont
import math
import random
import csv

"""
Main File to insert data into an SQL table.

"""

dictionary = {
    # Varchar

    "A0": "F. NAME (M) [varchar]",
    "A1": "F. NAME (F) [varchar]",
    "A2": "LAST NAME [varchar]",

    # Char

    "B0": "GENDER [char]",

    # Int

    "C0": "AGE [int]"
}

"""
Constant Global Variable
"""

gender = ["M", "F", "O"]


"""
Data Insertion Code
"""

categoryList = []
category = None


def addToList(ID, mainAppFrame):
    global categoryList
    categoryList.append(ID)
    global category
    if category is tk.Frame:
        category.grid_forget()
    category = InitCategoryList(mainAppFrame)
    category.grid(row=2, column=3, rowspan=3, padx=175, pady=25, sticky="NW")


def clearList(mainAppFrame):
    global categoryList
    categoryList = []
    global category
    category = InitCategoryList(mainAppFrame)
    category.grid(row=2, column=3, rowspan=3, padx=175, pady=25, sticky="NW")


def insertDataPoints(rowsInserted, tableName, columnList, dataTypeList, connection):
    if tableName is None:
        return

    numberOfRows = 0
    numberOfColumns = len(columnList)

    if len(categoryList) != numberOfColumns:
        tk.messagebox.showinfo('Error Message', 'The number of categories must equal the number of columns.')
        return

    dataTypeIterator = 0
    for dataType in dataTypeList:
        if dataType == "[varchar]":
            if categoryList[dataTypeIterator][0] != str("A"):
                tk.messagebox.showinfo('Error Message', 'The data types of the columns and categories must match.')
                return
        if dataType == "[char]":
            if categoryList[dataTypeIterator][0] != str("B"):
                tk.messagebox.showinfo('Error Message', 'The data types of the columns and categories must match.')
                return
        if dataType == "[int]":
            if categoryList[dataTypeIterator][0] != str("C"):
                tk.messagebox.showinfo('Error Message', 'The data types of the columns and categories must match.')
                return

        dataTypeIterator += 1

    try:
        numberOfRows = int(rowsInserted)
    except:
        tk.messagebox.showinfo('Error Message', 'Please type an integer into the "Number of Rows" field.')
        return

    # Execution Query Setup

    formattedColumnList = []

    for column in columnList:
        temp = "`"
        temp += column
        temp +="`"
        formattedColumnList.append(temp)

    for i in range(numberOfRows):
        rowInserter = connection.cursor()

        insertQuery = "INSERT INTO " + tableName + " ("
        insertQueryList = []

        for num in range(numberOfColumns):
            if num == numberOfColumns - 1:
                insertQuery = insertQuery + "" + formattedColumnList[num] + ") "
            else:
                insertQuery = insertQuery + "" + formattedColumnList[num] + ", "

        insertQuery = insertQuery + "VALUES ("

        for num in range(numberOfColumns):
            if num == numberOfColumns - 1:
                insertQuery = insertQuery + "%s)"
            else:
                insertQuery = insertQuery + "%s, "

        # Data Insertion Points

        for temp in categoryList:
            insertQueryList.append(sqlDataCreator(temp))

        insertQueryTuple = tuple(insertQueryList)

        try:
            rowInserter.execute(insertQuery, insertQueryTuple)
        except:
            print("")

    connection.commit()

def sqlDataCreator(ID):
    if ID == "A0": # First Name Male
        with open('Names.csv', 'r') as csvObj:
            csvReader = csv.reader(csvObj)
            rows = list(csvReader)
            rowNumber = random.randrange(0, 1000)
            return rows[rowNumber][0]
        return None
    elif ID == "A1": # First Name Female
        with open('Names.csv', 'r') as csvObj:
            csvReader = csv.reader(csvObj)
            rows = list(csvReader)
            rowNumber = random.randrange(0, 1000)
            return rows[rowNumber][1]
        return None
    elif ID == "A2": # Last Name
        with open('Names.csv', 'r') as csvObj:
            csvReader = csv.reader(csvObj)
            rows = list(csvReader)
            rowNumber = random.randrange(0, 1000)
            return rows[rowNumber][2]
        return None
    elif ID == "B0": # Gender
        return random.choice(gender)
    elif ID == "C0": # Age
        return math.trunc(random.random() * 100)

def clearTable(tableName, connection):
    if tableName is None:
        return
    deletor = connection.cursor()
    try:
        deletor.execute("TRUNCATE TABLE `" + tableName + "`")
    except:
        tk.messagebox.showinfo('Error Message', 'An error has occured with clearing the table.\nNote tables with keys cannot be cleared as of this version.\nEmpty tables also cannot be cleared.')
    connection.commit()

class InitCategoryList(tk.Frame):
    def __init__(self, mainAppFrame):
        tk.Frame.__init__(self, mainAppFrame)
        # Initializing the fonts.

        self.titleFont = tkFont.Font(family="Helvetica", size=40, weight="bold")
        self.headingFont = tkFont.Font(family="Helvetica", size=30, weight="bold")
        self.dataModificationButtonFont = tkFont.Font(family="Helvetica", size=16, weight="bold")
        self.rowLabelFont = tkFont.Font(family="Helvetica", size=16)
        self.rowEntryFont = tkFont.Font(family="Helvetica", size=16)
        self.versionFont = tkFont.Font(family="Helvetica", size=16, weight="bold")

        # Initializing scrolling frame.

        self.categoryCanvas = tk.Canvas(self)
        self.categoryScrollBar = tk.Scrollbar(self, orient="vertical",
                                              command=self.categoryCanvas.yview)
        self.categoryScrollFrame = tk.Frame(self.categoryCanvas)

        self.categoryCanvas.create_window((0, 0), window=self.categoryScrollFrame, anchor="nw")
        self.categoryCanvas.configure(yscrollcommand=self.categoryScrollBar.set)
        self.categoryCanvas.bind("<Configure>",
                                 lambda command: self.categoryCanvas.configure(
                                     scrollregion=self.categoryCanvas.bbox("all")))

        self.categoryCanvas.grid(row=0, column=0, sticky="W")
        self.categoryScrollBar.grid(row=0, column=0, sticky="NS")

        self.iterator = 0

        global categoryList

        for ID in categoryList:
            global dictionary
            label = dictionary[ID]
            temp = tk.Label(self.categoryScrollFrame, text=label)
            temp.grid(row=self.iterator, column=0, sticky="W")
            self.iterator += 1
