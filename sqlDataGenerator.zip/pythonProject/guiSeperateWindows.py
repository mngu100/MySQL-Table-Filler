import tkinter as tk
import tkinter.ttk as ttk
import tkinter.font as tkFont


def informationClicked(mainGUI):
    """
    Window Creation
    """

    informationWindow = tk.Toplevel(mainGUI)
    informationWindow.title("Application Information")
    informationWindow.geometry("475x600")
    informationWindow.resizable(False, False)

    """
    Creating the Tab Menu
    """
    # Creating The Tab Menu
    informationTab = ttk.Notebook(informationWindow)

    # Creating The Tabs

    introductionTab = tk.Frame(informationTab)
    instructionTab = tk.Frame(informationTab)
    versionTab = tk.Frame(informationTab)

    # Adding the Tabs to the Tab Menu
    informationTab.add(introductionTab, text="Introduction")
    informationTab.add(instructionTab, text="Instructions")
    informationTab.add(versionTab, text="Update Log")

    # Packing the Tab Menu

    informationTab.pack(expand=True, fill="both", side="top")

    """
    Making the Tabbed Frames Scrollable.
    """

    # Introduction Tab

    introductionCanvas = tk.Canvas(introductionTab)
    introductionScrollBar = tk.Scrollbar(introductionTab, orient="vertical", command=introductionCanvas.yview)
    introductionScrollFrame = tk.Frame(introductionCanvas)

    introductionScrollFrame.bind("<Configure>", lambda command: introductionCanvas.configure(scrollregion=introductionCanvas.bbox("all")))
    introductionCanvas.create_window((0, 0), window=introductionScrollFrame, anchor="nw")
    introductionCanvas.configure(yscrollcommand=introductionScrollBar.set)

    introductionCanvas.pack(side="left", fill="both", expand=True)
    introductionScrollBar.pack(side="right", fill="y")

    # Instruction Tab

    instructionCanvas = tk.Canvas(instructionTab)
    instructionScrollBar = tk.Scrollbar(instructionTab, orient="vertical", command=instructionCanvas.yview)
    instructionScrollFrame = tk.Frame(instructionCanvas)

    instructionScrollFrame.bind("<Configure>", lambda command: instructionCanvas.configure(scrollregion=instructionCanvas.bbox("all")))
    instructionCanvas.create_window((0, 0), window=instructionScrollFrame, anchor="nw")
    instructionCanvas.configure(yscrollcommand=instructionScrollBar.set)

    instructionCanvas.pack(side="left", fill="both", expand=True)
    instructionScrollBar.pack(side="right", fill="y")

    # Version Tab

    versionCanvas = tk.Canvas(versionTab)
    versionScrollbar = tk.Scrollbar(versionTab, orient="vertical", command=versionCanvas.yview)
    versionScrollFrame = tk.Frame(versionCanvas)

    versionScrollFrame.bind("<Configure>", lambda command: versionCanvas.configure(scrollregion=versionCanvas.bbox("all")))
    versionCanvas.create_window((0, 0), window=versionScrollFrame, anchor="nw")
    versionCanvas.configure(yscrollcommand=versionScrollbar.set)

    versionCanvas.pack(side="left", fill="both", expand=True)
    versionScrollbar.pack(side="right", fill="y")

    """
    Tab contents
    """

    # Introduction Tab

    #Initializing

    introductionBodyFont = tkFont.Font(family="Helvetica", size=12)

    introduction = """This is a senior year project that was developed by Stephen N."""

    introductionLabel = tk.Label(introductionScrollFrame, text=introduction, anchor="center")

    #Configuring

    introductionLabel.configure(font=introductionBodyFont)

    #Placing Items

    introductionLabel.pack(side="left", expand=True, fill="both")

    # Instructions Tab

    #Initializing
    instructionsBodyFont = tkFont.Font(family="Helvetica", size=12)

    instructions = """\n As of this version. The application is unable to view Databases\nwithin your MySQL / MariaDB server. You will need to use\nother software to view it or the Linux Terminal.\n\n
Instructions:\n
1. Click a selectable table.\n
2. Click a SQL data type to view categories of data with that type.\nThe other buttons under categories work the same way\n
3. Add a category of data based on an SQL data type.\n
4. The number of categories must be equal to\nthe amount of columns (unless specified otherwise).\n
5. The SQL data type of a category must be the same type\n as the SQL data type of the column.\n
Note: You can clear the category list\nif you enter too many categories\n
6. Click the insert data button.
"""

    instructionsLabel = tk.Label(instructionScrollFrame, text=instructions, anchor="nw")

    #Configuring

    instructionsLabel.configure(font=instructionsBodyFont)

    #Placing Items

    instructionsLabel.pack(side="left", expand=True, fill="both")

    # Version Tab

    #Initializing
    updateFont = tkFont.Font(family="Helvetica", size=12, weight="bold")
    version1000 = tk.Label(versionScrollFrame, text="2021/3/31 1.0.0.0 - App Release Date\n")

    #Configuring
    version1000.configure(font=updateFont)

    #Placing Items
    version1000.pack()


def optionClicked():
    tk.messagebox.showinfo('Options',
                           'This feature is not currently implemented. It will be updated in a future version')
