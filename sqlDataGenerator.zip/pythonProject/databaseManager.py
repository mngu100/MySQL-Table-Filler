import pymysql.cursors
import tkinter as tk
import tkinter.messagebox

import guiLogIn as logIn
import guiMainPage as mainPage


class CurrentSession:
    def __init__(self):
        self.connection = None

    def logIn(self, username, password, hostname, databaseName, guiManager, currentSession, mainGUI):
        # If any fields are blank this will happen. This is needed since if username & password are correct...
        # The connection can still be established.
        if username == "" or password == "" or hostname == "" or databaseName == "":
            tk.messagebox.showinfo('Login Status', 'Please enter data in all fields.')
            return
        try:
            self.connection = pymysql.connect(user=username, password=password, host=hostname, db=databaseName, cursorclass=pymysql.cursors.DictCursor)
        except:
            tk.messagebox.showinfo('Login Status', 'Invalid Credentials\nPlease enter the information in again.')
        else:
            guiManager.hidePage()
            pageCreation = mainPage.MainApplicationPage(guiManager, currentSession, mainGUI, databaseName)
            guiManager.showPage(pageCreation)

    def logOut(self, guiManager, currentSession, mainGUI):
        guiManager.hidePage()
        pageCreation = logIn.LogInPage(guiManager, currentSession, mainGUI)
        guiManager.showPage(pageCreation)