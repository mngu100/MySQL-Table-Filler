import tkinter as tk
import guiManager as gM
import databaseManager as dM

# Creates the application window and runs through it.

applicationWindow = tk.Tk()
currentSession = dM.CurrentSession()
gM.MainApplication(applicationWindow, currentSession)
applicationWindow.mainloop()
