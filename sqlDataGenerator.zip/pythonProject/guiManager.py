import tkinter as tk

import guiLogIn as logIn

"""
Page IDs:

0 = Login Page
1 = Main Application Page
"""


class MainApplication(tk.Tk):
    # Initialization method for entire the class.
    def __init__(self, parent, currentSession):  # Parent is synonymous with root.

        # Initializing Application Settings

        self.root = parent
        self.root.title("Randomized Data generator for MySQL / MariaDB")
        self.root.geometry("1168x824")

        self.root.resizable(False, False)

        # Initializing the main frame.

        self.currentPage = None
        self.showPage(logIn.LogInPage(self, currentSession, self.root))

    def showPage(self, newPage):
        self.currentPage = newPage
        self.currentPage.grid(row=0, column=0)

    def hidePage(self):
        self.currentPage.grid_remove()