import tkinter as tk
import tkinter.font as tkFont
import guiSeperateWindows as gSW
import dataInsertion as dI

CurrentTableSelected = None
ColumnList = []
DataList = []

class MainApplicationPage(tk.Frame):
    # Initialization Method for the class.
    def __init__(self, guiManager, currentSession, mainGUI, databaseName):
        tk.Frame.__init__(self)

        # Initializing the Database Connection and Variables used across all methods.

        self.connection = currentSession.connection

        # Initializing the fonts.

        self.titleFont = tkFont.Font(family="Helvetica", size=40, weight="bold")
        self.headingFont = tkFont.Font(family="Helvetica", size=30, weight="bold")
        self.dataModificationButtonFont = tkFont.Font(family="Helvetica", size=16, weight="bold")
        self.rowLabelFont = tkFont.Font(family="Helvetica", size=16)
        self.rowEntryFont = tkFont.Font(family="Helvetica", size=16)
        self.versionFont = tkFont.Font(family="Helvetica", size=16, weight="bold")

        # Initializing the addable contents via their Methods.

        self.title = tk.Label(self, text="Main App Page")
        self.tablesListLabel = tk.Label(self, text="Tables List:")
        self.selectedCategoriesListLabel = tk.Label(self, text="Categories List:")
        self.columnLabel = tk.Label(self, text="Column List:")
        self.categoryLabel = tk.Label(self, text="Data Type List:")
        self.dataCategoryLabel = tk.Label(self, text="Data Insertion:")
        self.addCategoryLabel = tk.Label(self, text="Add Category:")
        self.versionLabel = tk.Label(self, text="Version: 1.0.0.0")
        self.dateUpdated = tk.Label(self, text="Updated: March 31st 2021")

        self.initMainToolbar(guiManager, currentSession, mainGUI)

        # Creating Interactive Objects.

        self.tables = InitTablesRadioButtons(self, databaseName, self.connection)
        self.chooseable = InitChooseableList(self)
        self.data = InitDataList(self, self.chooseable)
        self.insertion = InitInsertionList(self, self.tables.tableNameList, self.connection)

        # Configuring the added contents.

        self.title.configure(font=self.titleFont)
        self.tablesListLabel.configure(font=self.headingFont)
        self.selectedCategoriesListLabel.configure(font=self.headingFont)
        self.columnLabel.configure(font=self.headingFont)
        self.categoryLabel.configure(font=self.headingFont)
        self.dataCategoryLabel.configure(font=self.headingFont)
        self.addCategoryLabel.configure(font=self.headingFont)
        self.versionLabel.configure(font=self.versionFont)
        self.dateUpdated.configure(font=self.versionFont)

        # Adding non-method contents.

        self.title.grid(row=0, column=2, pady=15, ipady=15, sticky="NEW")
        self.tablesListLabel.grid(row=1, column=0, padx=10, sticky="NW")
        self.selectedCategoriesListLabel.grid(row=1, column=3, padx=75, sticky="NW")
        self.columnLabel.grid(row=1, column=2, sticky="NEW")
        self.categoryLabel.grid(row=5, column=3, padx=95, sticky="NW")
        self.addCategoryLabel.grid(row=5, column=0, padx=10, sticky="NW")
        self.dataCategoryLabel.grid(row=5, column=2, sticky="EW")
        self.versionLabel.grid(row=0, column=0, sticky="W", padx=10)
        self.dateUpdated.grid(row=0, column=3, sticky="W", padx=120)



    """
    Toolbar and Toolbar Methods
    """

    # noinspection PyAttributeOutsideInit
    def initMainToolbar(self, guiManager, currentSession, mainGUI):
        # Initializing the toolbar.

        toolMenu = tk.Menu()
        mainGUI.config(menu=toolMenu)

        # Adding the toolbar components

        toolMenu.add_command(label="Info", command=lambda: gSW.informationClicked(mainGUI))
        toolMenu.add_command(label="Options", command=lambda: gSW.optionClicked())
        toolMenu.add_command(label="Log Out",
                             command=lambda: currentSession.logOut(guiManager, currentSession, mainGUI))

""""
Other Created GUI Components on the Main Page
"""


class InitTablesRadioButtons:
    def __init__(self, mainAppFrame, databaseName, connection):
        # Initializing components for the Radio Button
        self.tableNameRadio = tk.IntVar()
        self.tableNameList = []
        self.radioTableFont = tkFont.Font(family="Helvetica", size=16)

        self.currentPage = 0

        # Initializing scrolling frame.

        self.radioButtonFrame = tk.Frame(mainAppFrame)
        self.radioCanvas = tk.Canvas(self.radioButtonFrame)
        self.radioScrollbar = tk.Scrollbar(self.radioButtonFrame, orient="vertical", command=self.radioCanvas.yview)
        self.radioScrollFrame = tk.Frame(self.radioCanvas)

        self.radioCanvas.create_window((0, 0), window=self.radioScrollFrame, anchor="nw")
        self.radioCanvas.configure(yscrollcommand=self.radioScrollbar.set)
        self.radioCanvas.bind("<Configure>", lambda command: self.radioCanvas.configure(scrollregion=self.radioCanvas.bbox("all")))

        self.radioButtonFrame.grid(row=2, rowspan=3, column=0, pady=25, sticky="NW")
        self.radioCanvas.grid(row=0, column=0)
        self.radioScrollbar.grid(row=0, column=0, sticky="NSE")

        # Filling the Table Name List with Table Names
        self.tableNameFinder = connection.cursor()

        self.tableRetrievalQuery = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' AND TABLE_SCHEMA=%s"
        self.tableNameFinder.execute(self.tableRetrievalQuery, databaseName)

        self.rawTableNames = self.tableNameFinder.fetchall()

        for name in self.rawTableNames:
            tableName = name.get("TABLE_NAME")
            temp = "".join(tableName)
            self.tableNameList.append(temp)

        # Creating the Radio Buttons from the Table Name List

        self.iterator = 0
        self.columnList = []

        for name in self.tableNameList:
            temp = InitColumnList(mainAppFrame, name, connection)
            self.columnList.append(temp)
            self.radioButton = tk.Radiobutton(self.radioScrollFrame, text=name, variable=self.tableNameRadio, value=self.iterator, command=lambda:self.showColumn())
            self.radioButton.configure(font=self.radioTableFont)
            self.radioButton.grid(row=self.iterator, column=0, sticky="NSEW")
            self.iterator += 1

        self.currentColumn = self.columnList[0]
        self.label = tk.Label(self.radioScrollFrame, text="Click on a button to load column list").grid(row=self.iterator, column=0, padx=10, pady=50)

    def showColumn(self):
        global CurrentTableSelected
        global ColumnList
        global DataList
        CurrentTableSelected = self.tableNameRadio.get()
        self.currentColumn.grid_forget()
        self.currentColumn = self.columnList[self.tableNameRadio.get()]
        ColumnList = self.currentColumn.columnNameList
        DataList = self.currentColumn.dataList
        self.currentColumn.grid(row=2, column=2, rowspan=3, pady=25, sticky="E")

    def showTableSelected(self):
        print("Hello")


class InitColumnList(tk.Frame):
    def __init__(self, mainAppFrame, tableName, connection):
        tk.Frame.__init__(self, mainAppFrame)
        # Initializing the fonts.

        self.titleFont = tkFont.Font(family="Helvetica", size=40, weight="bold")
        self.headingFont = tkFont.Font(family="Helvetica", size=30, weight="bold")
        self.dataModificationButtonFont = tkFont.Font(family="Helvetica", size=16, weight="bold")
        self.rowLabelFont = tkFont.Font(family="Helvetica", size=16)
        self.rowEntryFont = tkFont.Font(family="Helvetica", size=16)
        self.versionFont = tkFont.Font(family="Helvetica", size=16, weight="bold")

        # Initializing scrolling frame.

        self.columnCanvas = tk.Canvas(self)
        self.columnScrollBar = tk.Scrollbar(self, orient="vertical", command=self.columnCanvas.yview)
        self.columnScrollFrame = tk.Frame(self.columnCanvas)

        self.columnCanvas.create_window((0, 0), window=self.columnScrollFrame, anchor="center")
        self.columnCanvas.configure(yscrollcommand=self.columnScrollBar.set)
        self.columnCanvas.bind("<Configure>", lambda command: self.columnCanvas.configure(scrollregion=self.columnCanvas.bbox("all")))

        self.columnCanvas.grid(row=0, column=0, sticky="E")
        self.columnScrollBar.grid(row=0, column=0, sticky="NSE")

        # Loading Columns

        columnRetriever = connection.cursor()
        dataTypeRetriever = connection.cursor()

        query = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = %s"
        columnRetriever.execute(query, (tableName,))

        self.columnNames = columnRetriever.fetchall()

        query = "SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = %s"
        dataTypeRetriever.execute(query, (tableName,))

        self.dataTypes = dataTypeRetriever.fetchall()

        self.columnNameList = []
        self.dataList = []
        iterator = 0

        for data in self.dataTypes:
            temp = data.get("DATA_TYPE")
            temp = "".join(temp)
            dataType = "[" + temp + "]"
            self.dataList.append(dataType)

        for column in self.columnNames:
            temp = column.get("COLUMN_NAME")
            dataType = self.dataList[iterator]

            columnName = "".join(temp)
            self.columnNameList.append(columnName)

            labelText = columnName + " " + dataType

            tk.Label(self.columnScrollFrame, text=labelText).grid(row=iterator, column=0, sticky="E")
            iterator += 1


"""
SQL Data Insertion Related GUI
"""


class InitInsertionList:
    def __init__(self, mainAppFrame, tableList, connection):
        # Initializing the fonts.

        self.titleFont = tkFont.Font(family="Helvetica", size=40, weight="bold")
        self.headingFont = tkFont.Font(family="Helvetica", size=30, weight="bold")
        self.dataModificationButtonFont = tkFont.Font(family="Helvetica", size=16, weight="bold")
        self.rowLabelFont = tkFont.Font(family="Helvetica", size=16)
        self.rowEntryFont = tkFont.Font(family="Helvetica", size=16)
        self.versionFont = tkFont.Font(family="Helvetica", size=16, weight="bold")

        # Initializing scrolling frame.

        self.insertionListFrame = tk.Frame(mainAppFrame)
        self.insertionCanvas = tk.Canvas(self.insertionListFrame)
        self.insertionScrollBar = tk.Scrollbar(self.insertionListFrame, orient="vertical", command=self.insertionCanvas.yview)
        self.insertionScrollFrame = tk.Frame(self.insertionCanvas)

        self.insertionCanvas.create_window((0, 0), window=self.insertionScrollFrame, anchor="nw")
        self.insertionCanvas.configure(yscrollcommand=self.insertionScrollBar.set)
        self.insertionCanvas.bind("<Configure>",
                             lambda command: self.insertionCanvas.configure(scrollregion=self.insertionCanvas.bbox("all")))

        self.insertionListFrame.grid(row=6, column=2, rowspan=4, pady=25, sticky="E")
        self.insertionCanvas.grid(row=0, column=0)
        self.insertionScrollBar.grid(row=0, column=0, sticky="NSE")

        """
        Inserting Components
        """

        # Initialization

        global ColumnList

        self.rowsInsertedLabel = tk.Label(self.insertionScrollFrame, text="Number of Rows to Insert:")
        self.rowsInsertedEntry = tk.Entry(self.insertionScrollFrame)
        self.dataInsertionButton = tk.Button(self.insertionScrollFrame, text="Insert Data", bg="blue", fg="white", command=lambda: dI.insertDataPoints(self.rowsInsertedEntry.get(), self.retrieveTable(tableList), ColumnList, DataList, connection))
        self.parameterDeletionButton = tk.Button(self.insertionScrollFrame, text="Clear Parameters", bg="black", fg="white", command=lambda: dI.clearList(mainAppFrame))
        self.tableDeletionButton = tk.Button(self.insertionScrollFrame, text="Clear Table", bg="grey", fg="black", command=lambda: dI.clearTable(self.retrieveTable(tableList), connection))

        # Configuring

        self.rowsInsertedLabel.configure(font=self.rowLabelFont)
        self.rowsInsertedEntry.configure(font=self.rowEntryFont)
        self.dataInsertionButton.configure(font=self.dataModificationButtonFont)
        self.parameterDeletionButton.configure(font=self.dataModificationButtonFont)
        self.tableDeletionButton.configure(font=self.dataModificationButtonFont)

        # Griding

        self.rowsInsertedLabel.grid(row=0, column=0, padx=60, sticky="SEW")
        self.rowsInsertedEntry.grid(row=1, column=0, sticky="NEW")
        self.dataInsertionButton.grid(row=2, column=0, ipadx=30, ipady=10, sticky="SWE")
        self.parameterDeletionButton.grid(row=3, column=0, ipadx=30, ipady=10, sticky="NEW")
        self.tableDeletionButton.grid(row=4, column=0, ipadx=30, ipady=10, sticky="EW")

    def retrieveTable(self, tableList):
        global CurrentTableSelected
        if CurrentTableSelected is None:
            tk.messagebox.showinfo('Error', 'Please select a table.\nThe program will only execute if the column list is visible.')
            return None
        return tableList[CurrentTableSelected]

class InitDataList:
    def __init__(self, mainAppFrame, choosableList):
        # Initializing the fonts.

        self.titleFont = tkFont.Font(family="Helvetica", size=40, weight="bold")
        self.headingFont = tkFont.Font(family="Helvetica", size=30, weight="bold")
        self.dataModificationButtonFont = tkFont.Font(family="Helvetica", size=16, weight="bold")
        self.rowLabelFont = tkFont.Font(family="Helvetica", size=16)
        self.rowEntryFont = tkFont.Font(family="Helvetica", size=16)
        self.versionFont = tkFont.Font(family="Helvetica", size=16, weight="bold")

        # Initializing scrolling frame.

        self.dataListFrame = tk.Frame(mainAppFrame)
        self.dataCanvas = tk.Canvas(self.dataListFrame)
        self.dataScrollBar = tk.Scrollbar(self.dataListFrame, orient="vertical", command=self.dataCanvas.yview)
        self.dataScrollFrame = tk.Frame(self.dataCanvas)

        self.dataCanvas.create_window((0, 0), window=self.dataScrollFrame, anchor="nw")
        self.dataCanvas.configure(yscrollcommand=self.dataScrollBar.set)
        self.dataCanvas.bind("<Configure>",
                            lambda command: self.dataCanvas.configure(scrollregion=self.dataCanvas.bbox("all")))

        self.dataListFrame.grid(row=6, column=3, rowspan=4, padx=175, pady=25, sticky="NE")
        self.dataCanvas.grid(row=0, column=0)
        self.dataScrollBar.grid(row=0, column=0, sticky="NS")

        self.varcharButton = tk.Button(self.dataScrollFrame, text="VARCHAR", command=lambda: self.showColumn(choosableList, 0)).grid(row=0, column=0, ipadx=50, sticky="W")
        self.charButton = tk.Button(self.dataScrollFrame, text="CHAR", command=lambda: self.showColumn(choosableList, 1)).grid(row=1, column=0, ipadx=65, sticky="W")
        self.intButton = tk.Button(self.dataScrollFrame, text="INT", command=lambda: self.showColumn(choosableList, 2)).grid(row=2, column=0, ipadx=70, sticky="W")

        # Loading in Categories

        self.currentFrame = choosableList.categoryList[0]

    def showColumn(self, chooseableList, index):
        self.currentFrame.grid_forget()
        self.currentFrame = chooseableList.categoryList[index]
        self.currentFrame.grid(row=0, column=0)


class InitChooseableList:
    def __init__(self, mainAppFrame):
        # Initializing the fonts.

        self.titleFont = tkFont.Font(family="Helvetica", size=40, weight="bold")
        self.headingFont = tkFont.Font(family="Helvetica", size=30, weight="bold")
        self.dataModificationButtonFont = tkFont.Font(family="Helvetica", size=16, weight="bold")
        self.rowLabelFont = tkFont.Font(family="Helvetica", size=16)
        self.rowEntryFont = tkFont.Font(family="Helvetica", size=16)
        self.versionFont = tkFont.Font(family="Helvetica", size=16, weight="bold")

        # Initializing scrolling frame.

        self.chooseListFrame = tk.Frame(mainAppFrame)
        self.chooseCanvas = tk.Canvas(self.chooseListFrame)
        self.chooseScrollBar = tk.Scrollbar(self.chooseListFrame, orient="vertical", command=self.chooseCanvas.yview)
        self.chooseScrollFrame = tk.Frame(self.chooseCanvas)

        self.chooseCanvas.create_window((0, 0), window=self.chooseScrollFrame, anchor="nw")
        self.chooseCanvas.configure(yscrollcommand=self.chooseScrollBar.set)
        self.chooseCanvas.bind("<Configure>",
                               lambda command: self.chooseCanvas.configure(scrollregion=self.chooseCanvas.bbox("all")))

        self.chooseListFrame.grid(row=6, column=0, rowspan=4, pady=25, sticky="NE")
        self.chooseCanvas.grid(row=0, column=0)
        self.chooseScrollBar.grid(row=0, column=0, sticky="NSE")

        """
        Category Frames
        """

        self.categoryList = []

        # Varchar Buttons. (Frame = 0)

        self.varcharFrame = tk.Frame(self.chooseScrollFrame)

        self.mascName = tk.Button(self.varcharFrame, text="First Name [Masc]", command=lambda: dI.addToList("A0", mainAppFrame)).grid(row=0, column=0, sticky="W", ipadx=50)
        self.femName = tk.Button(self.varcharFrame, text="First Name [Fem]", command=lambda: dI.addToList("A1", mainAppFrame)).grid(row=1, column=0, sticky="W", ipadx=50)
        self.lastName = tk.Button(self.varcharFrame, text="Last Name", command=lambda: dI.addToList("A2", mainAppFrame)).grid(row=2, column=0, sticky="W", ipadx=50)

        self.categoryList.append(self.varcharFrame)

        # Char Buttons. (Frame = 1)

        self.charFrame = tk.Frame(self.chooseScrollFrame)

        self.gender = tk.Button(self.charFrame, text="Gender", command=lambda: dI.addToList("B0", mainAppFrame)).grid(row=0, column=0)

        self.categoryList.append(self.charFrame)

        # Int Buttons. (Frame = 2)

        self.intFrame = tk.Frame(self.chooseScrollFrame)

        self.age = tk.Button(self.intFrame, text="Age", command=lambda: dI.addToList("C0", mainAppFrame)).grid(row=0, column=0)

        self.categoryList.append(self.intFrame)
