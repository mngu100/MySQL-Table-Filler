import tkinter as tk
import tkinter.font as tkFont


# Log In Page

class LogInPage(tk.Frame):
    # Initialization Method for the class.
    def __init__(self, guiManager, currentSession, mainGUI):
        tk.Frame.__init__(self)

        # Creating fonts to use

        titleFont = tkFont.Font(family="Helvetica", size=45, weight="bold")
        definitionFont = tkFont.Font(family="Helvetica", size=24, weight="bold")
        entryFont = tkFont.Font(family="Helvetica", size=24)
        loginFont = tkFont.Font(family="Helvetica", size=30)

        # Initializing addable contents

        self.loginTitle = tk.Label(self, text="MariaDB / MySQL Data Generator")
        self.usernameLabel = tk.Label(self, text="Username:")
        self.passwordLabel = tk.Label(self, text="Password:")
        self.hostnameLabel = tk.Label(self, text="Hostname: ")
        self.databaseNameLabel = tk.Label(self, text="Database Name: ")

        self.usernameEntry = tk.Entry(self)
        self.passwordEntry = tk.Entry(self, show="*")
        self.hostnameEntry = tk.Entry(self)
        self.databaseNameEntry = tk.Entry(self)

        self.logInButton = tk.Button(self, text="Login", bg="black", fg="white",
                                     command=lambda: self.loginAttempt(guiManager, currentSession, mainGUI))
        self.creditsButton = tk.Button(self, text="Credits", bg="black", fg="white")

        self.initLogInToolbar(mainGUI)

        # Configuring the addable contents

        self.loginTitle.configure(font=titleFont)
        self.usernameLabel.configure(font=definitionFont)
        self.passwordLabel.configure(font=definitionFont)
        self.hostnameLabel.configure(font=definitionFont)
        self.databaseNameLabel.configure(font=definitionFont)

        self.usernameEntry.configure(font=entryFont)
        self.passwordEntry.configure(font=entryFont)
        self.hostnameEntry.configure(font=entryFont)
        self.databaseNameEntry.configure(font=entryFont)

        self.logInButton.configure(font=loginFont)

        # Placing contents within the grid.

        self.loginTitle.grid(row=0, column=0, columnspan=3, padx=130, pady=70, ipady=75)
        self.usernameLabel.grid(row=1, column=0, pady=25, sticky="E")
        self.passwordLabel.grid(row=2, column=0, pady=25, sticky="E")
        self.hostnameLabel.grid(row=3, column=0, pady=25, sticky="E")
        self.databaseNameLabel.grid(row=4, column=0, pady=25, sticky="E")

        self.usernameEntry.grid(row=1, column=1, padx=20, sticky="EW")
        self.passwordEntry.grid(row=2, column=1, padx=20, sticky="EW")
        self.hostnameEntry.grid(row=3, column=1, padx=20, sticky="EW")
        self.databaseNameEntry.grid(row=4, column=1, padx=20, sticky="EW")

        self.logInButton.grid(row=1, column=2, rowspan=2, ipadx=75, ipady=40, sticky="EW")

    @staticmethod
    def initLogInToolbar(mainGUI):
        # Initializing the toolbar.
        toolMenu = tk.Menu()
        mainGUI.config(menu=toolMenu)

    def loginAttempt(self, guiManager, currentSession, mainGUI):
        currentSession.logIn(self.usernameEntry.get(), self.passwordEntry.get(), self.hostnameEntry.get(),
                        self.databaseNameEntry.get(), guiManager, currentSession, mainGUI)
